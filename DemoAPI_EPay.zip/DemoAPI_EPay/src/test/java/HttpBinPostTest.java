import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class HttpBinPostTest {

    @Test
    public void verifyStatusAndContent() {
        // Set base URI for API endpoint
        RestAssured.baseURI = "https://httpbin.org";

        // Define request body
        String requestBody = "{\n" +
                "\"student\":\"Tim Allen\",\n" +
                "\"email_address\": \"tim@homeimprovement.com\",\n" +
                "\"phone\": \"(408) 8674530\",\n" +
                "\"current_grade\": \"B+\",\n" +
                "\"topping\": [\n" +
                "\"bacon\",\n" +
                "\"cheese\",\n" +
                "\"mushroom\"\n" +
                "]\n" +
                "}";

        // Send POST request with request body and verify status code is 200 or 201
        given().contentType(ContentType.JSON).body(requestBody).post("/post")
                .then().statusCode(anyOf(is(200), is(201)));

        // Verify that the topping is bacon, cheese, and mushroom and does not contain chicken
        given().contentType(ContentType.JSON).body(requestBody).post("/post")
                .then().contentType(ContentType.JSON)
                .body("json.topping", hasItems("bacon", "cheese", "mushroom"))
                .body("json.topping", not(hasItem("chicken")));
    }
}