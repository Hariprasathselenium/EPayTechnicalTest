
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.*;

public class PostsAPITest {
	
	@Test
	public void DemoAPI() {
		// Set base URI for API endpoint
		RestAssured.baseURI = "https://jsonplaceholder.typicode.com/posts";

		// Send GET request and verify status code is 200 OK
		given().get().then().statusCode(200).log().all();
		//System.out.println("Response for GET Request as below : " +bodyValue);

		// Verify all title and body fields have content
		given().get().then().contentType(ContentType.JSON).body("title", not(emptyString())).body("body",
				not(emptyString()));

		// Verify none of the fields contain the word "zombie"
		given().get().then().contentType(ContentType.JSON).body("title", not(containsString("zombie"))).body("body",
				not(containsString("zombie")));
	}
}